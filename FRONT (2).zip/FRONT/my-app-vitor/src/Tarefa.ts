export interface Tarefa {

    id : string;
    titulo : string;
    descricao : string;
    criadoEm: Date;
    categoria : string;
    categoriaId : string;
    concluida : string;


}