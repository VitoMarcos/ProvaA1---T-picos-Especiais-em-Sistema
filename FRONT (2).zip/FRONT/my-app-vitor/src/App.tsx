import React from 'react';
import { BrowserRouter, Route, Routes, Link } from 'react-router-dom';
import CadastrarTarefas from './Componentes/CadastrarTarefas';
import ListaTarefas from './Componentes/ListaTarefas';
import TarefaAlterar from './Componentes/AlterarTarefas';

const App: React.FC = () => {
    return (
        <BrowserRouter>
            <div className="App">
                <nav>
                    <ul>
                        <li>
                            <Link to="/">Lista de Tarefas</Link>
                        </li>
                        <li>
                            <Link to="/cadastro">Cadastro de Tarefas</Link>
                        </li>
                        <li>
                            <Link to="/alterar">Alterar as Tarefas</Link>
                        </li>
                    </ul>
                </nav>
                <Routes>
                    <Route path="/" element={<ListaTarefas />} />
                    <Route path="/cadastro" element={<CadastrarTarefas />} />
                    <Route path="/alterar" element={<TarefaAlterar/>}></Route>
                </Routes>
            </div>
        </BrowserRouter>
    );
};

export default App;