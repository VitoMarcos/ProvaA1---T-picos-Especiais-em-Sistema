import React, { useState } from 'react';
import { Tarefa } from '../Tarefa';

function CadastroTarefa() {
    const [titulo, setTitulo] = useState<string>('');
    const [descricao, setDescricao] = useState<string>('');
    const [categoria, setCategoria] = useState<string>('');
    const [concluida, setConcluida] = useState<string>('');

    function handleSubmit (e: any) {
        e.preventDefault();

        const novaTarefa = {
            titulo,
            descricao,
            categoria,
            concluida
        };

        fetch('http://localhost:5000/tarefas/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(novaTarefa)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na requisição: ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            setTitulo('');
            setDescricao('');
            setCategoria('');
            setConcluida('');
        })
        .catch(error => {
            console.error('Erro:', error);
        });
    };

    return (
        <div>
            <h2>Cadastrar Nova Tarefa</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Titulo:
                    <input type="text" value={titulo} onChange={e => setTitulo(e.target.value)} required />
                </label>
                <label>
                    Descrição:
                    <input type="text" value={descricao} onChange={e => setDescricao(e.target.value)} required />
                </label>
                <label>
                    Categoria:
                    <input type="text" value={categoria} onChange={e => setCategoria(e.target.value)} required />
                </label>
                <label>
                    Concluida?
                    <input type="text" value={concluida} onChange={e => setConcluida(e.target.value)} required />
                </label>
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    );
};

export default CadastroTarefa;