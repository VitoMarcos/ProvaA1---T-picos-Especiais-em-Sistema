import { useEffect, useState } from "react";
import { Tarefa } from "../Tarefa";
import { useNavigate, useParams } from "react-router-dom";

function TarefaAlterar() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [categoria, setCategoria] = useState("");
  const [concluida, setConcluida] = useState("");
  } [];

  function alterarTarefa(e: any) {
    const Tarefa: TarefaAlterar = {
      titulo: titulo,
      descricao: descricao,
      categoria: categoria,
      concluida: concluida,
      categoriaId: "8c726096-28b3-4807-9722-fb3b07695008",
    };
    //FETCH ou AXIOS
    fetch(`http://localhost:5000/tarefas/alterar/`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(Tarefa),
    })
      .then((resposta) => resposta.json())
      .then((tarefa: Tarefa) => {
        navigate("/componentes/tarefa/listar");
      });
    e.preventDefault();
  }
  return (
    <div>
      <h1>Alterar tarefa</h1>
      <form onSubmit={alterarTarefa}>
        <label>Titulo:</label>
        <input
          type="text"
          value={titulo}
          placeholder="Digite o nome"
          onChange={(e: any) => setTitulo(e.target.value)}
          required
        />
        <br />
        <label>Descricao:</label>
        <input
          type="text"
          value={descricao}
          placeholder="Digite o descrição"
          onChange={(e: any) => setDescricao(e.target.value)}
        />
        <br />
        <label>Categoria:</label>
        <input
          type="text"
          value={categoria}
          placeholder="Digite a categoria"
          onChange={(e: any) => setCategoria(e.target.value)}
        />
        <br />
        <label>Concluída:</label>
        <input
          type="text"
          value={concluida}
          placeholder="Digite o valor"
          onChange={(e: any) => setConcluida(e.target.value)}
        />
        <br />
        <button type="submit">Salvar</button>
      </form>
    </div>
  );


export default TarefaAlterar;
