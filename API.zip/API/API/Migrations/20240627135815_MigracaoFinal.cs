﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API.Migrations
{
    /// <inheritdoc />
    public partial class MigracaoFinal : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "concluida",
                table: "Tarefas",
                type: "TEXT",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "INTEGER");

            migrationBuilder.UpdateData(
                table: "Categorias",
                keyColumn: "CategoriaId",
                keyValue: "39be53a2-fc09-4b6a-bafa-18a6a23c8f6e",
                column: "CriadoEm",
                value: new DateTime(2024, 6, 30, 10, 58, 15, 94, DateTimeKind.Local).AddTicks(4386));

            migrationBuilder.UpdateData(
                table: "Categorias",
                keyColumn: "CategoriaId",
                keyValue: "6d091456-5a2f-4b5a-98fc-f1a3b50a627d",
                column: "CriadoEm",
                value: new DateTime(2024, 6, 29, 10, 58, 15, 94, DateTimeKind.Local).AddTicks(4381));

            migrationBuilder.UpdateData(
                table: "Categorias",
                keyColumn: "CategoriaId",
                keyValue: "bfe4e7dc-81e4-4e47-a67b-d4fbf3e124bd",
                column: "CriadoEm",
                value: new DateTime(2024, 6, 28, 10, 58, 15, 94, DateTimeKind.Local).AddTicks(4373));

            migrationBuilder.UpdateData(
                table: "Tarefas",
                keyColumn: "TarefaId",
                keyValue: "2f1b7dc1-3b9a-4e1a-a389-7f5d2f1c8f3e",
                columns: new[] { "CriadoEm", "concluida" },
                values: new object[] { new DateTime(2024, 6, 30, 10, 58, 15, 94, DateTimeKind.Local).AddTicks(4520), "finalizada" });

            migrationBuilder.UpdateData(
                table: "Tarefas",
                keyColumn: "TarefaId",
                keyValue: "6a8b3e4d-5e4e-4f7e-bdc9-9181e456ad0e",
                columns: new[] { "CriadoEm", "concluida" },
                values: new object[] { new DateTime(2024, 7, 4, 10, 58, 15, 94, DateTimeKind.Local).AddTicks(4514), "não finalizada" });

            migrationBuilder.UpdateData(
                table: "Tarefas",
                keyColumn: "TarefaId",
                keyValue: "e5d4a7b9-1f9e-4c4a-ae3b-5b7c1a9d2e3f",
                columns: new[] { "CriadoEm", "concluida" },
                values: new object[] { new DateTime(2024, 7, 11, 10, 58, 15, 94, DateTimeKind.Local).AddTicks(4525), "não finalizada" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<bool>(
                name: "concluida",
                table: "Tarefas",
                type: "INTEGER",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(string),
                oldType: "TEXT",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "Categorias",
                keyColumn: "CategoriaId",
                keyValue: "39be53a2-fc09-4b6a-bafa-18a6a23c8f6e",
                column: "CriadoEm",
                value: new DateTime(2024, 6, 30, 9, 43, 26, 847, DateTimeKind.Local).AddTicks(9489));

            migrationBuilder.UpdateData(
                table: "Categorias",
                keyColumn: "CategoriaId",
                keyValue: "6d091456-5a2f-4b5a-98fc-f1a3b50a627d",
                column: "CriadoEm",
                value: new DateTime(2024, 6, 29, 9, 43, 26, 847, DateTimeKind.Local).AddTicks(9484));

            migrationBuilder.UpdateData(
                table: "Categorias",
                keyColumn: "CategoriaId",
                keyValue: "bfe4e7dc-81e4-4e47-a67b-d4fbf3e124bd",
                column: "CriadoEm",
                value: new DateTime(2024, 6, 28, 9, 43, 26, 847, DateTimeKind.Local).AddTicks(9475));

            migrationBuilder.UpdateData(
                table: "Tarefas",
                keyColumn: "TarefaId",
                keyValue: "2f1b7dc1-3b9a-4e1a-a389-7f5d2f1c8f3e",
                columns: new[] { "CriadoEm", "concluida" },
                values: new object[] { new DateTime(2024, 6, 30, 9, 43, 26, 847, DateTimeKind.Local).AddTicks(9626), false });

            migrationBuilder.UpdateData(
                table: "Tarefas",
                keyColumn: "TarefaId",
                keyValue: "6a8b3e4d-5e4e-4f7e-bdc9-9181e456ad0e",
                columns: new[] { "CriadoEm", "concluida" },
                values: new object[] { new DateTime(2024, 7, 4, 9, 43, 26, 847, DateTimeKind.Local).AddTicks(9620), false });

            migrationBuilder.UpdateData(
                table: "Tarefas",
                keyColumn: "TarefaId",
                keyValue: "e5d4a7b9-1f9e-4c4a-ae3b-5b7c1a9d2e3f",
                columns: new[] { "CriadoEm", "concluida" },
                values: new object[] { new DateTime(2024, 7, 11, 9, 43, 26, 847, DateTimeKind.Local).AddTicks(9631), false });
        }
    }
}
